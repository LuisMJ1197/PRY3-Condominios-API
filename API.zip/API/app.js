const Express = require("express");
const BodyParser = require("body-parser");
const MongoClient = require("mongodb").MongoClient;
const ObjectId = require("mongodb").ObjectID;
const CONNECTION_URL = "mongodb+srv://luismj:luisito138@luiscluster.cmour.mongodb.net/mlDesigner?retryWrites=true&w=majority";
const DATABASE_NAME = "mlDesigner";
const cors = require('cors');
 
var app = Express();
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true }));
var database, collection;

app.use(cors());

app.listen(5000, () => {
    MongoClient.connect(CONNECTION_URL, { useNewUrlParser: true, useUnifiedTopology: true}, (error, client) => {
        if(error) {
            throw error;
        }
        database = client.db(DATABASE_NAME);
        console.log("Connected to `" + DATABASE_NAME + "`!");
    });
});

app.post("/addarchitect", (request, response) => {
    collection = database.collection("architect");
    collection.insertOne(request.body, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok, "data": result.ops[0]._id});
    });
});

app.get("/directions", (request, response) => {
    collection = database.collection("directions");
    collection.find({}).toArray((error, result) => {
        if (error) {
            return response.status(500).send(error);
        }
        response.send(result);
    });
});

app.get("/architects", (request, response) => {
    collection = database.collection("architect");
    collection.find({}).toArray((error, result) => {
        if (error) {
            return response.status(500).send(error);
        }
        response.send(result);
    });
});

app.get("/designs", (request, response) => {
    collection = database.collection("house");
    collection.find({}).toArray((error, result) => {
        if (error) {
            return response.status(500).send(error);
        }
        response.send(result);
    });
});

app.post("/adddesign", (request, response) => {
    collection = database.collection("house");
    collection.insertOne(request.body, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok, "data": result.ops[0]._id});
    });
});


app.put("/updatedesign", (request, response) => {
    collection = database.collection("house");
    var myquery = { _id: ObjectId(request.body._id) };
    delete request.body["_id"];
    collection.updateOne(myquery, {$set: request.body}, {upsert: true}, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok});
    });
});

app.post("/deletedesign", (request, response) => {
    collection = database.collection("house");
    var myquery = { _id: ObjectId(request.body._id) };
    collection.deleteOne(myquery, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok});
    });
});

app.get("/condoprojects", (request, response) => {
    collection = database.collection("condo");
    collection.find({}).toArray((error, result) => {
        if (error) {
            return response.status(500).send(error);
        }
        response.send(result);
    });
});

app.post("/addcondoproject", (request, response) => {
    collection = database.collection("condo");
    collection.insertOne(request.body, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok, "data": result.ops[0]._id});
    });
});


app.put("/updatecondoproject", (request, response) => {
    collection = database.collection("condo");
    var myquery = { _id: ObjectId(request.body._id) };
    delete request.body["_id"];
    collection.updateOne(myquery, {$set: request.body}, {upsert: true}, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok});
    });
});

app.post("/deletecondoproject", (request, response) => {
    collection = database.collection("condo");
    var myquery = { _id: ObjectId(request.body._id) };
    collection.deleteOne(myquery, (error, result) => {
        if(error) {
            return response.status(500).send(error);
        }
        response.send({"ok": result.result.ok});
    });
});